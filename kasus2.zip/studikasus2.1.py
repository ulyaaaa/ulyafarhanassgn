import studikasus2
db = studikasus2.studikasus2(host='localhost', port = '3306', user = 'root',password = '')
print(db.create_db('studikasus'))
print(db.create_table('studikasus','tablestudikasus','df'))
print(db.load_data('studikasus','tablestudikasus'))
print(db.import_csv("C:\Users\Acer\Downloads\addresses.csv"))
print(db.save_result_to_csv())